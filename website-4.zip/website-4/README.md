# website 4

- Name : "Master Company"

- Description : "Self Bussiness"

- Version : 4.4

- Update : 24-06-2023

- Status : REST

- Responsive : Ture

- TecStack : { HTML | CSS | JavaScript | JSON }

- Thanks : { VSCodium | GitHub | Fontawesome | GoogleFont | GoogleMap | Unplash }

- Work : Self

- Design : { Mayank }

- Developer : { Mayank }

- CopyRight : { Master Compnay }

- URL : https://mayankdevil.github.io/website-4/

- Clone : https://github.com/MayankDevil/website-4.git

- Download : https://github.com/MayankDevil/website-4/archive/refs/heads/main.zip

---

### Home Page

![Alt text](./data/MasterCompany.png "HomePage")


### Architecture

_Component base architecture improve reuseablity and reduce code help easy to modify._

### Responsive

**Breakpoints** { 576 | 768 | 992 | 1200 }

### Theme Mode

_Blue colour theme with require colour, it is companay website that represent Company._




