/*
-	website-4 "Master"
-	CopyRight by Master Mayank
-	Design & Developed by Mayank
-	JavaScript : js/price_Data
*/
try
{
	/*
		===============================================================
		| PRICE DATA |
		===============================================================
	*/
	price_Data = [
          {
            url : "#",
            title : "Standered",
            charge : 50,
            time : 'per/month',
            offer : [
                "Repdevelope and stand web.",
                "Full project stablise.",
                "Repdevelope and stand web.",
                "Repdevelope and stand web.",
                "Repdevelope and stand web.",
                "Develope full web or software."
            ]
        },
        {
            url : "#",
            title : "Business",
            charge : 100,
            time : 'per/month',
            offer : [
                "Repdevelope and stand web.",
                "Full project stablise.",
                "Repdevelope and stand web.",
                "Repdevelope and stand web.",
                "Develope full web or software."
            ]
        },
        {
            url : "#",
            title : "Basic",
            charge : 10,
            time : 'per/month',
            offer : [
                "Repdevelope and stand web.",
                "Full project stablise.",
                "Repdevelope and stand web.",
                "Repdevelope and stand web.",
                "Repdevelope and stand web.",
                "Develope full web or software."
            ]
        }
    ] 
    /*
        ===============================================================
    */ 
}
catch(error)
{
	alert(console.error(error));
}