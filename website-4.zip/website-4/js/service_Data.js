/*
-	website-4 "Master"
-	CopyRight by Master Mayank
-	Design & Developed by Mayank
-	JavaScript : js/service_Data
*/
try
{
	/*
		===============================================================
		| SERVICE DATA |
		===============================================================
	*/
	service_Data = [
        {
            name : "Software Programming",
            blog : "Develope or build Software by hardcore programming.",
            icon : "<span class='bi bi-laptop'></span>",
            url : null
        },
        {
            name : "DataBase Management",
            blog : "Create Insert Or Update Data in Large Database.",
            icon : "<span class='bi bi-server'></span>",
            url : null
        },
        {
            name : "Website Developement",
            blog : "Develope website front & backend and web application or Admin Panels.",
            icon : "<span class='bi bi-display'></span>",
            url : null
        },
        {
            name : "Android Application",
            blog : "Build Android appliction games or projects according Requirement.",
            icon : "<span class='bi bi-phone'></span>",
            url : null
        },
        {
            name : "Server Management",
            blog : "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, nostrum?",
            icon : "<span class='bi bi-router'></span>",
            url : null
        },
        {
            name : "Ethical Hacking",
            blog : "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, nostrum?",
            icon : "<span class='bi bi-keyboard'></span>",
            url : null
        },
        {
            name : "Debbuging & Testing",
            blog : "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, nostrum?",
            icon : "<span class='bi bi-reception-4'></span>",
            url : null
        },
        {
            name : "Project Anylises",
            blog : "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, nostrum?",
            icon : "<span class='bi bi-globe'></span>",
            url : null
        },
        {
            name : "-- UI / UX Design --",
            blog : "Unauthories Access Accounts, Blackmailing, Password Cracking, Data Curapting",
            icon : "<span class='bi bi-brush'></span>",
            url : null
        }
    ] 
    /*
        ===============================================================
    */
}
catch(error)
{
	console.log("fucking something")
}
