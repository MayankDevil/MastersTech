/*
-	website-4 "Master"
-	CopyRight by Master Mayank
-	Design & Developed by Mayank
-	JavaScript : js/team_Data
*/
try
{
	/*
		===============================================================
		| TEAM DATA |
		===============================================================
	*/
	team_Data = [
          {
               name : "Hritik",
               image : "Hritik.jpg",
               qoute : "Our Democracy Has Been Hacked",
               protfolio : "#"
          },
          {
               name : "Mayank",
               image : "self.png",
               qoute : "Think Simple Do Best, Make Harder in Easy Steps.",
               protfolio : "https://mastermayank.w3spaces.com"
          },
          {
               name : "Alisha",
               image : "Alisha.jpg",
               qoute : null,
               protfolio : "https://alishabeg.github.io/AlishaBeg/"
          },
          {
               name : "Suraj",
               image : "Suraj.png",
               qoute : null,
               protfolio : "https://surajsingh.vercel.app/"
          },
          {
               name : "Rohit",
               image : "Rohit.jpg",
               qoute : "The Data is Power of New World, To Got Future Information!",
               protfolio : "#"
          },
          {
               name : "Uday",
               image : "Uday.jpg",
               qoute : null,
               protfolio : "#"
          },
          {
               name : "Anash",
               image : "Anash.jpg",
               qoute : null,
               protfolio : "#"
          }
     ]
     
     /*
          ===============================================================
     */ 
}
catch(error)
{
	alert(console.error(error));
}